<?php
if (session_status() === PHP_SESSION_NONE) session_start();

if (
    !isset($_SESSION['user_id']) || 
    !isset($_SESSION['user']['user_type']) ||
    $_SESSION['user']['user_type'] !== 'importer'
) {
    header("Location: ../../login/login.php");
    exit;
}

$importer_name = $_SESSION['user']['full_name'] ?? 'Importer';
$company_name = $_SESSION['user']['company_name'] ?? 'Importer Company';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($company_name); ?> Dashboard - Port Management System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header class="header">
        <div class="header-content">
            <h1 class="header-title"><?php echo htmlspecialchars($company_name); ?></h1>
        </div>
        <div class="header-user">
            <span>Welcome, <?php echo htmlspecialchars($importer_name); ?>!</span>
            <a href="/pms/logout.php" class="logout-button">Logout</a>
        </div>
    </header>

    <main class="container">
        <div class="card">
            <h2>Upload Documents</h2>
            <form id="upload-form">
                <div class="form-group">
                    <label for="container-id">Container / Shipment ID</label>
                    <input type="text" id="container-id" name="container-id">
                </div>
                <div class="form-group">
                    <label for="document">Document</label>
                    <input type="file" id="document" name="document">
                </div>
                <button type="submit" class="btn">Upload</button>
            </form>
        </div>

        <div class="card">
            <h2>Cargo Status</h2>
            <table id="cargo-status-table">
                <thead>
                    <tr>
                        <th>Container</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>CONT-101</td>
                        <td>Awaiting Clearance</td>
                        <td><button class="btn btn-refresh">Refresh</button></td>
                    </tr>
                    <!-- More rows can be added dynamically -->
                </tbody>
            </table>
        </div>

        <div class="card">
            <h2>Delivery Info & Invoices</h2>
            <p>Track transport type, scheduled and actual arrival, view invoices.</p>
        </div>
    </main>

    <footer class="footer">
        <p>Port Management System © 2025</p>
    </footer>

    <script src="script.js"></script>
</body>
</html>
