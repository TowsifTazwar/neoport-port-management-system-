<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once '../../config/db.php';

header('Content-Type: application/json');

if (
    !isset($_SESSION['user_id']) || 
    !isset($_SESSION['user']['user_type']) ||
    $_SESSION['user']['user_type'] !== 'importer'
) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$response = ['success' => false, 'message' => 'Invalid request.'];
$pdo = pms_pdo();

$importer_id = $_SESSION['user']['id'];

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $action = $_GET['action'] ?? '';

    try {
        if ($action === 'get_dashboard_data') {
            // Example: Fetching data relevant to the importer
            // This will need to be adjusted based on the actual data importers need to see.
            // For now, let's assume we're fetching their shipments and invoices.

            // Fetch shipments for the importer
            $shipments_stmt = $pdo->prepare(
                "SELECT s.id, s.ship_name, s.status, DATE_FORMAT(s.estimated_arrival_time, '%Y-%m-%d') AS eta
                 FROM shipments s
                 WHERE s.importer_id = ? ORDER BY s.estimated_arrival_time DESC"
            );
            $shipments_stmt->execute([$importer_id]);
            $shipments = $shipments_stmt->fetchAll(PDO::FETCH_ASSOC);

            // Fetch invoices for the importer
            $invoices_stmt = $pdo->prepare(
                "SELECT i.invoice_number, i.amount, i.status, i.file_path 
                 FROM invoices i
                 JOIN shipments s ON i.shipment_id = s.id
                 WHERE s.importer_id = ? ORDER BY i.created_at DESC"
            );
            $invoices_stmt->execute([$importer_id]);
            $invoices = $invoices_stmt->fetchAll(PDO::FETCH_ASSOC);

            $response = [
                'success' => true, 
                'data' => [
                    'shipments' => $shipments,
                    'invoices' => $invoices
                ]
            ];
        } else {
            http_response_code(400);
            $response['message'] = 'Invalid GET action.';
        }
    } catch (Exception $e) {
        http_response_code(500);
        $response['message'] = 'Database error: ' . $e->getMessage();
    }
}

echo json_encode($response);
