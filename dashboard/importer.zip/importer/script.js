document.addEventListener('DOMContentLoaded', function() {
    fetchDashboardData();
});

function fetchDashboardData() {
    fetch('importer_api.php?action=get_dashboard_data')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                populateShipmentsTable(data.data.shipments);
                populateInvoicesTable(data.data.invoices);
            } else {
                console.error('Failed to fetch dashboard data:', data.message);
            }
        })
        .catch(error => console.error('Error fetching dashboard data:', error));
}

function populateShipmentsTable(shipments) {
    const tableBody = document.getElementById('shipments-table').querySelector('tbody');
    tableBody.innerHTML = ''; 

    if (shipments.length === 0) {
        tableBody.innerHTML = '<tr><td colspan="4">No shipments found.</td></tr>';
        return;
    }

    shipments.forEach(shipment => {
        const row = `<tr>
            <td>${shipment.id}</td>
            <td>${shipment.ship_name}</td>
            <td>${shipment.status}</td>
            <td>${shipment.eta}</td>
        </tr>`;
        tableBody.innerHTML += row;
    });
}

function populateInvoicesTable(invoices) {
    const tableBody = document.getElementById('invoices-table').querySelector('tbody');
    tableBody.innerHTML = '';

    if (invoices.length === 0) {
        tableBody.innerHTML = '<tr><td colspan="4">No invoices found.</td></tr>';
        return;
    }

    invoices.forEach(invoice => {
        const row = `<tr>
            <td>${invoice.invoice_number}</td>
            <td>${invoice.amount}</td>
            <td>${invoice.status}</td>
            <td><a href="${invoice.file_path}" target="_blank">Download</a></td>
        </tr>`;
        tableBody.innerHTML += row;
    });
}
